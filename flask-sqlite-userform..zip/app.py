from flask import Flask, g, render_template, request, redirect, url_for, flash
import sqlite3
import os

DATABASE = os.path.join(os.path.dirname(__file__), 'users.db')

app = Flask(__name__)
app.secret_key = 'change_this_secret_in_production'

# --- utilitaires DB ---

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

# --- routes ---

@app.route('/')
def index():
    return redirect(url_for('register'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        message = request.form.get('message', '').strip()

        if not name or not email:
            flash("Le nom et l'email sont requis.", 'error')
            return redirect(url_for('register'))

        db = get_db()
        try:
            db.execute('INSERT INTO users (name, email, message) VALUES (?, ?, ?)',
                       (name, email, message))
            db.commit()
            flash('Utilisateur enregistré avec succès.', 'success')
            return redirect(url_for('list_users'))
        except sqlite3.IntegrityError:
            flash('Cet email est déjà enregistré.', 'error')
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/users')
def list_users():
    db = get_db()
    cur = db.execute('SELECT id, name, email, message, created_at FROM users ORDER BY created_at DESC')
    users = cur.fetchall()
    return render_template('list.html', users=users)

if __name__ == '__main__':
    # Initialise la DB si besoin
    if not os.path.exists(DATABASE):
        import db_init
        db_init.init_db(DATABASE)
    app.run(debug=True)
