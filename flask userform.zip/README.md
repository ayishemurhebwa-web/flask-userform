# Flask + SQLite - Formulaire utilisateur

1. Créer un environnement virtuel (recommandé):
   python -m venv venv
   source venv/bin/activate   # Linux/macOS
   venv\Scripts\activate    # Windows

2. Installer les dépendances:
   pip install -r requirements.txt

3. Initialiser la base de données:
   python db_init.py

4. Lancer l'application:
   python app.py

5. Ouvre http://127.0.0.1:5000 dans ton navigateur.

Notes:
- Pour la production, change `app.secret_key`, désactive `debug`, et utilise un serveur WSGI (gunicorn/uwsgi) derrière un reverse proxy.
- Si tu veux une API JSON au lieu d'un formulaire HTML, je peux l'ajouter.
