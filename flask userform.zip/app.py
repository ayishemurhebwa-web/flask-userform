from flask import Flask, request, render_template_string
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

init_db()

html_form = """
<!DOCTYPE html>
<html>
<head>
    <title>Formulaire utilisateur</title>
</head>
<body>
    <h2>Enregistrement utilisateur</h2>
    <form method="POST">
        Nom : <input type="text" name="name"><br><br>
        Email : <input type="email" name="email"><br><br>
        <button type="submit">Envoyer</button>
    </form>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]

        conn = sqlite3.connect("database.db")
        c = conn.cursor()
        c.execute("INSERT INTO users (name, email) VALUES (?, ?)", (name, email))
        conn.commit()
        conn.close()

        return "Utilisateur enregistré ! 🎉"

    return render_template_string(html_form)

if __name__ == "__main__":
    app.run(debug=True)
